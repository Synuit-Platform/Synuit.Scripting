ScintillaNET-Kitchen
====================

Cook your own recipes..!

Introduction
------------

[![Build status](https://ci.appveyor.com/api/projects/status/h5dk0ugkorhljpm6?svg=true)](https://ci.appveyor.com/project/uuf6429/scintillanet-kitchen)
[![codecov.io](https://codecov.io/github/uuf6429/ScintillaNET-Kitchen/coverage.svg?branch=master)](https://codecov.io/github/uuf6429/ScintillaNET-Kitchen?branch=master)

ScintillaNET-Kitchen is an application that not only demonstrates how Scintilla works, but it also (and most importantly) helps you with designing how scintilla should look like.

Requirements
------------

Thi software requires .NET 4.0 (Client Profile) and the ScintillaNET NuGet package, so nothing much to do from your side.

Screenshot(s)
-------------

![Screenshot](https://raw.githubusercontent.com/uuf6429/ScintillaNET-Kitchen/master/screenshot.png)